#include "stm32f4xx_spi_update.h"


//#define DATA[05];  //data need to be sent

void delay(void){
	for (uint32_t i=0 ;i<500000 ;i++);
}

void SPI_DATA_Inti(void);

int main(void)
{


	SPI_DATA_Inti();

	while (1)
	{

		unsigned char SPI_Data_transmission(DATA); //  data to be sent
		delay();
	}
	//return 0;
}

SPI_DATA_Inti()
{
	//SPI_handle_t SPIdataTX;
//SPI_handle_t	SPI_handle_t.pSPIx=SPI2;
	//SPI_handle_tSPI_ClockControl(SPI_Config_t *pSPIx,uint8_t EnorDi);

//SPI_handle_t	SPI_ClockControl(SPI2,ENABLE);
//	SPI_handle_t.


	/*SPI_handle_t.SPIConfig.SPI_Mode = BIDIMODE0 ;
	SPI_handle_t.SPI_PinConfig.SPI_DataFF = DFF0;
	//SPIdataTX.SPI_PinConfig.SPI_Mode = ;
	//SPIdataTX.SPI_PinConfig.SPI_Mode = ;
	SPI_handle_t.SPI_PinConfig.SPI_MSTR = MSTR1;
	SPI_ClockControl(SPI2,ENABLE );  */


}

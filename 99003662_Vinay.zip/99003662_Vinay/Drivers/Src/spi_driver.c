#include "spi_driver.h"



void SPI_ClockControl(SPI_Config_t *pSPIx,uint8_t EnorDi)
{ 	if(EnorDi==ENABLE)
	{
	if(pSPIx == SPI1)
		{

			SPI1_PCLK_EN();
		}
	else if(pSPIx == SPI2)
		{
		SPI2_PCLK_EN();
		}
	else if(pSPIx == SPI3)
		{
		SPI3_PCLK_EN();
		}

	}
	else
	{
		if(pSPIx == SPI1)
			{
			SPI1_PCLK_DIS();
			}
		else if(pSPIx == SPI2)
			{
			SPI2_PCLK_DIS();
			}
		else if(pSPIx == SPI3)
			{
			SPI3_PCLK_DIS();
			}

	}
}


void SPI_Init(SPI_handle_t *pSPI_Handle)
{
	uint32_t temp=0;


	// temp=(pSPI_Handle->SPIConfig.SPI_DeviceMode<<(pSPI_Handle->SPIConfig.GPIO_PinNumber));


}

void SPI_Tx(void)
{


}


void SPI_Rx(void)
{


}

void SPI_Interrupt_Config(void)
{


}



void SPI_Master_Init(void)
{
	//Set MOSI, SCK as Output
	DDRB = (1<<5)|(1<<3);

	//Enable SPI, Set as Master
	//Prescaler: Fosc/16, Enable Interrupts
	SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPRO);
}



void SPI_Slave_Init(void)
{
	DDRB=(1<<6);	//MISO as Output
	SCPR=(1<<SPE);	//Enable SPI
}



unsigned char SPI_Data_Transmission(unsigned char data)
{
	//Store data into buffer
	SPDR=data;

	//Wait until Transmission Complete
	while(!(SPSR & (1<<spif)));

	//data return
	return(SPDR);
}


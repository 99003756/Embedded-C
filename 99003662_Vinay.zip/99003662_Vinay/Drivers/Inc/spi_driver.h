#ifndef INC_SPI_DRIVER_H_
#define INC_SPI_DRIVER_H_

#include"stm32f4xx_spi_update.h"




#define BIDIMODE0   0     //2-line unidirectional data mode
#define BIDIMODE1   1     //1-line bidirectional data mode


#define DFF0	0 	      //8-bit data frame format for transmission/reception
#define DFF1	1 	      //16-bit data frame format for transmission/reception


#define CLKPOL0 0 	      //CK to 0 when idle
#define CLKPOL1 1 	      //CK to 1 when idle


#define CLKPH0 0          //The first clock transition is the first data capture edge
#define CLKPH1 1          //The second clock transition is the first data capture edge


#define SSM0 0            // SSM disabled
#define SSM1 1            // SSM disabled


#define MSTR0 0           // Slave configuration
#define MSTR1 1           // Master configuration



/*
 *  SPI Configuration Structure
 */

typedef struct
{
	uint8_t SPI_DeviceMode;
	uint8_t SPI_BusConfig;
	uint8_t SPI_Sclkspeed;
	uint8_t SPI_DFF;
	uint8_t SPI_CPOL;
	uint8_t SPI_CPHA;
	uint8_t SPI_SSM;
}SPI_Config_t;

/*
 * SPI handle Structure
 */
typedef struct
{
	SPI_RegDef_t   *pSPIx;
	SPI_Config_t    SPIConfig;
}SPI_handle_t;







/*
 *For SPI Initiallization
 */
void SPI_Init(SPI_handle_t *pSPI_Handle);



/*
 * For SPI Transfer Function
 */
void SPI_Tx(void);


/*
 * For SPI reciver Fuunction
 */
void SPI_Rx(void);


/*
 * For SPI Interrupt Config
 */
void SPI_Interrupt_Config(void);


/*
 * For Controlling the clock
 */

void SPI_ClockControl(Gpio_RegDef_t *pSPIx,uint8_t EnorDi);

/*
 * For master initialization
 */
void SPI_Master_Init(void);


/*
 * For Slave initialization
 */
void SPI_Slave_Init(void);

/*
 * Data transmission
 */
unsigned char SPI_Data_Transmission(unsigned char data);

#endif
